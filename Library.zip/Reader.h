#pragma once
#include <string>

using namespace std;
struct Reader
{
    string name_book;
    string author;
    string name;
    string lastname;
};
